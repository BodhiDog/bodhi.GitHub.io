import { basic, initSidebar, initTopbar } from './modules/layouts';

initSidebar();
initTopbar();
basic();
